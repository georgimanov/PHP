<?php
$firstName = "Georgi";
$lastName = "Georgiev";
$age = 25;
echo "My name is {$firstName} {$lastName} and I am {$age} years old." ;
?>