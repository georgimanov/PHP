<?php
$firstNumber = 1234.5678;
$secondNumber = 333;
echo round($firstNumber + $secondNumber, 2);
?>