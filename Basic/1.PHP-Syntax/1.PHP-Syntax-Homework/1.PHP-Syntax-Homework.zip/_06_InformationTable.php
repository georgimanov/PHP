<?php
$name ="Pesho";
$phoneNumber = "0882-321-423";
$age = "24";
$address = "Hadji Dimitar";

echo "<table style='border:1px solid black'>
<tr>
  <td>Name</td>
  <td>" . $name . "</td>
</tr>
<tr>
  <td>Phone number</td>
  <td>" . $phoneNumber . "</td>
</tr>
<tr>
  <td>Age</td>
  <td>" . $age . "</td>
</tr>
<tr>
  <td>Address</td>
  <td>" . $address . "</td>
</tr>
</table> ";

?>